package uz.gita.lesson30.data.databases

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import uz.gita.lesson30.data.dao.UserDao
import uz.gita.lesson30.data.entities.UserEntity
import uz.gita.lesson30.util.App

@Database(entities = [UserEntity::class], version = 1)
abstract class UserDatabase : RoomDatabase() {
    abstract fun getUserDao(): UserDao

    companion object {
        private lateinit var database: UserDatabase

        fun getUserDatabase(): UserDatabase {
            if (!::database.isInitialized) {
                database =
                    Room.databaseBuilder(App.instance, UserDatabase::class.java, "UserDatabase")
                        .allowMainThreadQueries()
                        .build()
            }
            return database
        }
    }
}