package uz.gita.lesson30.ui.adapters

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter
import uz.gita.lesson30.ui.pages.intro_pages.IntroPageBedtime
import uz.gita.lesson30.ui.pages.intro_pages.IntroPageGender
import uz.gita.lesson30.ui.pages.intro_pages.IntroPageWakeUp
import uz.gita.lesson30.ui.pages.intro_pages.IntroPageWeight

class IntroMainAdapter(fm: FragmentManager, lifecycle: Lifecycle) :
    FragmentStateAdapter(fm, lifecycle) {

    override fun getItemCount(): Int = 4

    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> IntroPageGender()
            1 -> IntroPageWeight()
            2 -> IntroPageWakeUp()
            else -> IntroPageBedtime()
        }
    }
}