package uz.gita.lesson30.data.dao

import androidx.room.*
import uz.gita.lesson30.data.entities.UserEntity

@Dao
interface UserDao{
    @Query("SELECT * FROM UserEntity")
    fun getAll(): List<UserEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertOrUpdate(data: UserEntity): Long

    @Insert(onConflict = OnConflictStrategy.ABORT)
    fun insertSingleItem(data: UserEntity): Long

    @Insert
    fun insertList(data: List<UserEntity>): List<Long>

    @Delete
    fun delete(data: UserEntity): Int

    @Update
    fun update(data: UserEntity): Int
}