package uz.gita.lesson30.ui.pages.intro_pages

import android.annotation.SuppressLint
import android.graphics.Paint
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.NumberPicker
import androidx.fragment.app.Fragment
import uz.gita.lesson30.R
import uz.gita.lesson30.data.databases.UserDatabase
import uz.gita.lesson30.databinding.PageIntroWeightBinding
import java.lang.reflect.Field


class IntroPageWeight : Fragment(R.layout.page_intro_weight) {
    private var _binding: PageIntroWeightBinding? = null
    private val binding get() = _binding!!
    private val userDao = UserDatabase.getUserDatabase().getUserDao()
    private val units = arrayOf("kg", "lbs")
  /*  private var buttonClickedListener: ((Int) -> Unit)? = null

    fun setButtonClickedListener(f: (Int) -> Unit) {
        buttonClickedListener = f
    }*/

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        _binding = PageIntroWeightBinding.bind(view)

        binding.weightPicker.minValue = 0
        binding.weightPicker.maxValue = 200
        binding.weightPicker.value = 70

        binding.weightPicker.setOnValueChangedListener(NumberPicker.OnValueChangeListener { picker, oldVal, newVal ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                picker.textColor = resources.getColor(R.color.blue)
            }
        })

        binding.unitPicker.minValue = 0
        binding.unitPicker.maxValue = 1
        binding.unitPicker.displayedValues = units

        binding.unitPicker.setOnValueChangedListener(NumberPicker.OnValueChangeListener { picker, oldVal, newVal ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                picker.textColor = resources.getColor(R.color.blue)
            }
        })

/*
        binding.introWeightNextBtn.setOnClickListener {
            buttonClickedListener?.invoke(1)
        }
        binding.introWeightBackBtn.setOnClickListener {
            buttonClickedListener?.invoke(0)
        }*/
    }

/*
    @SuppressLint("SoonBlockedPrivateApi")
    fun setNumberPickerTextColor(numberPicker: NumberPicker, color: Int) {
        try {
            val selectorWheelPaintField: Field = numberPicker.javaClass
                .getDeclaredField("mSelectorWheelPaint")
            selectorWheelPaintField.setAccessible(true)
            (selectorWheelPaintField.get(numberPicker) as Paint).setColor(color)
        } catch (e: NoSuchFieldException) {
            Log.w("TTT", e)
        } catch (e: IllegalAccessException) {
            Log.w("TTT", e)
        } catch (e: IllegalArgumentException) {
            Log.w("TTT", e)
        }
        val count = numberPicker.childCount
        for (i in 0 until count) {
            val child = numberPicker.getChildAt(i)
            if (child is EditText) child.setTextColor(color)
        }
        numberPicker.invalidate()
    }*/

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}