package uz.gita.lesson30.ui.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class IntroMainViewModel : ViewModel() {
    private val _selectGenderPageLiveData = MutableLiveData<Unit>()
    val selectGenderPageLiveData: LiveData<Unit> get() = _selectGenderPageLiveData

    private val _selectWeightPageLiveData = MutableLiveData<Unit>()
    val selectWeightPageLiveData: LiveData<Unit> get() = _selectWeightPageLiveData

    private val _selectWakeUpPageLiveData = MutableLiveData<Unit>()
    val selectWakeUpPageLiveData: LiveData<Unit> get() = _selectWakeUpPageLiveData

    private val _selectBedtimePageLiveData = MutableLiveData<Unit>()
    val selectBedtimePageLiveData: LiveData<Unit> get() = _selectBedtimePageLiveData

    private var position = 0

    fun changePagePos(pos: Int) {
        if (pos == position) return

        when (pos) {
            0 -> _selectGenderPageLiveData
            1 -> _selectWeightPageLiveData
            2 -> _selectWakeUpPageLiveData
            else -> _selectBedtimePageLiveData
        }.value = Unit

    }
}