package uz.gita.lesson30.ui.fragments.intro_fragments

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.viewpager2.widget.ViewPager2
import uz.gita.lesson30.R
import uz.gita.lesson30.data.databases.UserDatabase
import uz.gita.lesson30.databinding.ScreenIntroMainBinding
import uz.gita.lesson30.ui.adapters.IntroMainAdapter
import uz.gita.lesson30.ui.viewmodels.IntroMainViewModel

class IntroMainScreen : Fragment(R.layout.screen_intro_main) {
    private var _binding: ScreenIntroMainBinding? = null
    private val binding get() = _binding!!
    private val viewModel: IntroMainViewModel by viewModels()
    private val userDao = UserDatabase.getUserDatabase().getUserDao()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = ScreenIntroMainBinding.bind(view)
        val adapter = IntroMainAdapter(childFragmentManager, lifecycle)
        binding.introViewPager.adapter = adapter

        binding.introViewPager.registerOnPageChangeCallback(object :
            ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                viewModel.changePagePos(position)
            }
        })

        binding.bottomNavView.setOnItemSelectedListener {
            when (it.itemId) {
                R.id.menuItemGender -> {
                    viewModel.changePagePos(0)

                   /* arguments?.let {
                        val position = it.getInt()
                        viewModel.changePagePos()
                    }*/
                }
                R.id.menuItemWeight -> viewModel.changePagePos(1)
                R.id.menuItemWakeUp -> viewModel.changePagePos(2)
                else -> viewModel.changePagePos(3)
            }
            return@setOnItemSelectedListener true
        }

        viewModel.selectGenderPageLiveData.observe(viewLifecycleOwner, selectGenderPageObserver)
        viewModel.selectWeightPageLiveData.observe(viewLifecycleOwner, selectWeightPageObserver)
        viewModel.selectWakeUpPageLiveData.observe(viewLifecycleOwner, selectWakeUpPageObserver)
        viewModel.selectBedtimePageLiveData.observe(viewLifecycleOwner, selectBedtimePageObserver)
    }

    private val selectGenderPageObserver = Observer<Unit> {
        binding.introViewPager.currentItem = 0
    }
    private val selectWeightPageObserver = Observer<Unit> {
        binding.introViewPager.currentItem = 1
    }
    private val selectWakeUpPageObserver = Observer<Unit> {
        binding.introViewPager.currentItem = 2
    }
    private val selectBedtimePageObserver = Observer<Unit> {
        binding.introViewPager.currentItem = 3
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}