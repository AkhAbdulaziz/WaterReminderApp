package uz.gita.lesson30.ui.pages.intro_pages

import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import uz.gita.lesson30.R
import uz.gita.lesson30.databinding.PageIntroBedtimeBinding
import uz.gita.lesson30.databinding.PageIntroWakeupBinding

class IntroPageBedtime : Fragment(R.layout.page_intro_bedtime) {
    private var _binding: PageIntroBedtimeBinding? = null
    private val binding get() = _binding!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        _binding = PageIntroBedtimeBinding.bind(view)

        val minutes = ArrayList<String>()
        for (i in 0 until 24) {
            if (i < 10) {
                minutes.add("0$i")
            } else {
                minutes.add("$i")
            }
        }

        binding.hourPicker.minValue = 0
        binding.hourPicker.maxValue = 23
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            binding.hourPicker.textSize = 24f
        }
        binding.hourPicker.value = 22
        binding.hourPicker.displayedValues = minutes.toTypedArray()

        val seconds = ArrayList<String>()
        for (i in 0 until 60) {
            if (i < 10) {
                seconds.add("0$i")
            } else {
                seconds.add("$i")
            }
        }

        binding.secondPicker.minValue = 0
        binding.secondPicker.maxValue = 59
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            binding.hourPicker.textSize = 24f
        }
        binding.secondPicker.value = 0
        binding.secondPicker.displayedValues = seconds.toTypedArray()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}