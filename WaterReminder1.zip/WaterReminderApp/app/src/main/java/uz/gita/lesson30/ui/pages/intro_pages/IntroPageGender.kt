package uz.gita.lesson30.ui.pages.intro_pages

import androidx.fragment.app.Fragment
import uz.gita.lesson30.R

class IntroPageGender :Fragment(R.layout.page_intro_gender) {

}